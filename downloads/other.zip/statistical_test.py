import itertools
import numpy as np
import pandas as pd
from scipy.stats import chi2
from statsmodels.stats.contingency_tables import mcnemar

# =========================
# Load paired success matrix
# =========================
# CSV format example:
# case_id,Claude Opus 4.6,Deepseek v3.2,GPT-5.2,gemini 3 pro
# helper.java::getDrawingView,1,1,1,1
# ...

file_path = "rq1_paired_success_matrix_by_iteration.csv"
df = pd.read_csv(file_path)

# Keep only model columns
model_cols = [c for c in df.columns if c != "case_id"]
X = df[model_cols].astype(int).to_numpy()

N, k = X.shape
print(f"N cases = {N}")
print(f"k models = {k}")
print("Models:", model_cols)

# =========================
# 1. Cochran's Q test
# =========================
# Formula:
# Q = (k-1) * (k * sum(Cj^2) - T^2) / (k*T - sum(Ri^2))
# where:
#   Cj = column sums
#   Ri = row sums
#   T  = total number of successes

C = X.sum(axis=0)   # success count per model
R = X.sum(axis=1)   # success count per case
T = C.sum()

num = (k - 1) * (k * np.sum(C**2) - T**2)
den = k * T - np.sum(R**2)

Q = num / den if den != 0 else np.nan
p_Q = 1 - chi2.cdf(Q, df=k - 1)

print("\n=== Cochran's Q test ===")
print(f"Q = {Q:.6f}")
print(f"df = {k - 1}")
print(f"p = {p_Q:.10g}")

# =========================
# 2. Pairwise McNemar tests
# =========================
pairs = list(itertools.combinations(range(k), 2))
alpha = 0.05
alpha_bonf = alpha / len(pairs)

print("\n=== Pairwise McNemar tests ===")
print(f"Bonferroni-corrected alpha = {alpha_bonf:.10g}")

results = []

for i, j in pairs:
    # 2x2 paired table
    a = np.sum((X[:, i] == 1) & (X[:, j] == 1))  # both success
    b = np.sum((X[:, i] == 1) & (X[:, j] == 0))  # model i wins
    c = np.sum((X[:, i] == 0) & (X[:, j] == 1))  # model j wins
    d = np.sum((X[:, i] == 0) & (X[:, j] == 0))  # both fail

    table_2x2 = np.array([[a, b],
                          [c, d]])

    # exact McNemar test
    test = mcnemar(table_2x2, exact=True)
    p_val = test.pvalue

    # effect sizes
    risk_diff = X[:, i].mean() - X[:, j].mean()
    paired_or = (b + 0.5) / (c + 0.5)  # Haldane-Anscombe correction

    significant = p_val < alpha_bonf

    print(f"\n{model_cols[i]} vs {model_cols[j]}")
    print(f"a={a}, b={b}, c={c}, d={d}")
    print(f"p = {p_val:.10g}")
    print(f"significant after Bonferroni? {significant}")
    print(f"risk difference (A-B) = {risk_diff:.6f}")
    print(f"paired OR (b/c) = {paired_or:.6f}")

    results.append({
        "Model_A": model_cols[i],
        "Model_B": model_cols[j],
        "a_both_success": int(a),
        "b_A_wins": int(b),
        "c_B_wins": int(c),
        "d_both_fail": int(d),
        "p_value": float(p_val),
        "significant_bonf": bool(significant),
        "risk_diff_A_minus_B": float(risk_diff),
        "paired_OR_b_over_c": float(paired_or),
    })

# =========================
# 3. Save results
# =========================
results_df = pd.DataFrame(results)
results_df.to_csv("rq1_pairwise_mcnemar_results.csv", index=False)

print("\nSaved pairwise results to rq1_pairwise_mcnemar_results.csv")