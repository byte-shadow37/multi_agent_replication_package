import pandas as pd
import matplotlib.pyplot as plt

# Models
models = ["Claude Opus 4.6", "Deepseek v3.2", "GPT-5.2", "Gemini 3 Pro"]

# Success counts (out of 60 clone cases)
data = {
    "Full": [48, 44, 58, 57],
    "No RAG": [47, 20, 56, 51],
    "No Usefulness": [39, 30, 42, 48],
    "No Feedback Loop": [41, 21, 52, 50],
}

# Convert to success rate (%)
df = pd.DataFrame(data, index=models) / 60.0 * 100.0

# Soft pastel color palette (same style as previous figures)
colors = ["#f4a3a3", "#8fbce6", "#f6d186", "#a8d5ba"]

plt.figure(figsize=(10,5))

x = range(len(models))
bar_width = 0.18

# Plot grouped bars
for i, condition in enumerate(df.columns):
    plt.bar(
        [xi + (i - (len(df.columns)-1)/2) * bar_width for xi in x],
        df[condition].values,
        width=bar_width,
        color=colors[i],
        label=condition
    )

# Axis labels
plt.ylabel("Success Rate (%)")
plt.xticks(list(x), models, rotation=15)
plt.ylim(0, 100)

# Legend above plot to avoid overlap
plt.legend(
    loc="upper center",
    bbox_to_anchor=(0.5, 1.15),
    ncol=4,
    frameon=False
)

plt.tight_layout()

# Save figures
plt.savefig("rq2_ablation_success_rate_per_model.png", dpi=300, bbox_inches="tight")
plt.savefig("rq2_ablation_success_rate_per_model.pdf", bbox_inches="tight")

plt.show()